<?php 
$register_errors = array(
						1 => 'Username must be more than 3 symbols',
						2 => 'Pasword must be more than 3 symbols',
						3 => 'Paswords do not match',
						4 => 'Username already exists',
					);
$login_errors = array(
					1 => 'Wrong username or password'
				);
 
$user_salt = 'cvetino_djukati_be';
?>