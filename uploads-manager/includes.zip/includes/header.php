<?php date_default_timezone_set('Europe/Sofia'); ?>
<?php require_once 'includes/vars.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Upload Manager - <?= $page_title ?></title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
	<meta charset='UTF-8'>
</head>
<body>